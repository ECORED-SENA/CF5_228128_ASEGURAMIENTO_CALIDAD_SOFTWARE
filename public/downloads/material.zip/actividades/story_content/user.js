function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6LHa0xsgtxt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

